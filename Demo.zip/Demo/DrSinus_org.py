"""
CS6501 Cloud Computing
PA3 Part 3&4
Xinzuo Wang (xw3xp)
10/09/2018
This sample demonstrates an implementation of the Lex Code Hook Interface
in order to serve a sample bot which manages to check total with the input of day.
This .py file is based on AWS Lex templete.
Bot, Intent, and Slot models which are compatible with this sample can be found in the 
Lex Console as part of the 'OrderFlowers' template.
"""

import pymysql.cursors
import math
import dateutil.parser
import datetime
import time
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# query_rds function queries the database for informations at snotData.sql.
# This .sql is exported from http://drsinus.martyhumphrey.info/phpmyadmin/ as an .sql filedump,
# and imported to AWS RDS using AWS CLI. This database is open to public,
# and the credentials are shown as follows
def query_rds(pickup_time):
    # Database Connection Credentials
    rds_host = "sqlpa3part4test.cduxv3jn1joh.us-east-1.rds.amazonaws.com"
    user_name = "admin"
    password = "cellflue"
    db_name = "SQLPA3Part4Test"
    connection = pymysql.connect(rds_host, user_name, password, db_name, charset = 'utf8mb4', cursorclass = pymysql.cursors.DictCursor)
    #print ("successfully connect to snotData.sql!!")

    try:
        with connection.cursor() as cursor:
    	    output_score = -1;
            # SQL query based on the input (day)
            sql = "SELECT snot22_total FROM snotData WHERE day = %d"
            # Execute query.
            cursor.execute(sql % pickup_time) 
            # Print ("cursor.description: ", cursor.description)
            # Store the value of queried data (snot22_total) in output_score
            data = cursor.fetchone()
            output_score = data['snot22_total']

    finally:
    	# Close connection.
    	connection.close()
    	return output_score


def get_slots(intent_request):
    return intent_request['currentIntent']['slots']


def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message
        }
    }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }


""" --- Helper Functions --- """


def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def build_validation_result(is_valid, violated_slot, message_content):
    if message_content is None:
        return {
            "isValid": is_valid,
            "violatedSlot": violated_slot,
        }

    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }


def validate_order_flowers(pickup_time):
    if pickup_time is not None:
        # invalid number input
        if pickup_time < 1:
            return build_validation_result(False, 'PickupTime', 'The range of days {} is from 1 to 100. Please specify again.'.format(pickup_time))

    return build_validation_result(True, None, None)


""" --- Functions that control the bot's behavior --- """


def order_flowers(intent_request):
    """
    Performs dialog management and fulfillment for ordering flowers.
    Beyond fulfillment, the implementation of this intent demonstrates the use of the elicitSlot dialog action
    in slot validation and re-prompting.
    """

    pickup_time = get_slots(intent_request)["PickupTime"]
    source = intent_request['invocationSource']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        # Use the elicitSlot dialog action to re-prompt for the first violation detected.
        slots = get_slots(intent_request)

        validation_result = validate_order_flowers(pickup_time)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(intent_request['sessionAttributes'],
                               intent_request['currentIntent']['name'],
                               slots,
                               validation_result['violatedSlot'],
                               validation_result['message'])

        # Pass the price of the flowers back through session attributes to be used in various prompts defined
        # on the bot model.
        output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}

        return delegate(output_session_attributes, get_slots(intent_request))

    # Order the flowers, and rely on the goodbye message of the bot to define the message to the end user.
    # In a real bot, this would likely involve a call to a backend service.
    
    score = query_rds(int(pickup_time))
    
    return close(intent_request['sessionAttributes'],
                 'Fulfilled',
                 {'contentType': 'PlainText',
                  'content': 'The total score on day {} was {}.'.format(pickup_time, score)})


""" --- Intents --- """


def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """

    logger.debug('dispatch userId={}, intentName={}'.format(intent_request['userId'], intent_request['currentIntent']['name']))

    intent_name = intent_request['currentIntent']['name']

    # Dispatch to your bot's intent handlers
    if intent_name == 'OrderFlowers':
        return order_flowers(intent_request)

    raise Exception('Intent with name ' + intent_name + ' not supported')


""" --- Main handler --- """


def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    # By default, treat the user request as coming from the America/New_York time zone.
    os.environ['TZ'] = 'America/New_York'
    time.tzset()
    logger.debug('event.bot.name={}'.format(event['bot']['name']))

    return dispatch(event)

